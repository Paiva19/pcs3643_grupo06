--<ScriptOptions statementTerminator=";"/>

CREATE TABLE veiculos (
	id_veiculo INT NOT NULL AUTO_INCREMENT,
	modelo VARCHAR(100),
	PRIMARY KEY (id_veiculo)
);

